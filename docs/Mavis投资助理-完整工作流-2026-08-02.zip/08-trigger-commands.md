# MaxClaw 触发 GitHub Actions 命令模板

> 用户必须有自己的 GitHub PAT,设置成 MaxClaw 环境变量 `GITHUB_PAT`

---

## 通用 curl 模板

```bash
curl -X POST \
  -H "Authorization: token ${GITHUB_PAT}" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/Mavis-2026/mavis-portfolio/actions/workflows/task.yml/dispatches \
  -d '{"ref":"main","inputs":{...}}'
```

## 4 种任务类型

### 1. 每日复盘(主账户)
```bash
curl -X POST \
  -H "Authorization: token ${GITHUB_PAT}" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/Mavis-2026/mavis-portfolio/actions/workflows/task.yml/dispatches \
  -d '{"ref":"main","inputs":{"task":"review","account":"main","push_dingding":"true"}}'
```

### 2. 每日复盘(双账户)
```bash
curl -X POST \
  -H "Authorization: token ${GITHUB_PAT}" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/Mavis-2026/mavis-portfolio/actions/workflows/task.yml/dispatches \
  -d '{"ref":"main","inputs":{"task":"review","account":"both","push_dingding":"true"}}'
```

### 3. 盘中监测(3 段式 600-1200 字)
```bash
curl -X POST \
  -H "Authorization: token ${GITHUB_PAT}" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/Mavis-2026/mavis-portfolio/actions/workflows/task.yml/dispatches \
  -d '{"ref":"main","inputs":{"task":"position","account":"main","push_dingding":"true"}}'
```

### 4. 财经新闻
```bash
curl -X POST \
  -H "Authorization: token ${GITHUB_PAT}" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/Mavis-2026/mavis-portfolio/actions/workflows/task.yml/dispatches \
  -d '{"ref":"main","inputs":{"task":"news","account":"main","push_dingding":"true"}}'
```

### 5. 周复盘
```bash
curl -X POST \
  -H "Authorization: token ${GITHUB_PAT}" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/Mavis-2026/mavis-portfolio/actions/workflows/task.yml/dispatches \
  -d '{"ref":"main","inputs":{"task":"weekly","account":"both","push_dingding":"true"}}'
```

---

## 参数说明

| 参数 | 可选值 | 默认 |
|------|--------|------|
| `task` | `news` / `position` / `review` / `weekly` | `review` |
| `account` | `main` / `sub2` / `both` | `both` |
| `push_dingding` | `true` / `false` | `true` |

---

## 成功响应

```json
HTTP/1.1 204 No Content
```

## 失败处理

| 状态码 | 原因 | 解决 |
|--------|------|------|
| 401 | PAT 错/失效 | 重新生成 PAT |
| 403 | 权限不够 | 勾选 `workflow` scope |
| 404 | 仓库/工作流不存在 | 检查仓库名 |
| 422 | Workflow 没启用 dispatch trigger | 去 GitHub Actions 页面手动点一次 Run workflow |

---

## 完整工作流(从用户说指令到报告推送)

```
[你] 跟 MaxClaw 说"复盘"
        ↓
[MaxClaw] 收到,识别任务=review,账户=both
        ↓
[MaxClaw] curl 调 GitHub Actions API(用你的 GITHUB_PAT)
        ↓
[GitHub Actions] 跑 task.yml
   1. 读 DEEPSEEK_API_KEY(Demo Key)
   2. 拉持仓档 / 实时行情 / 估值
   3. 调 DeepSeek v4-pro 推理
   4. 生成 HTML + MD 报告
   5. 推钉钉
   6. commit + push 到 GitHub
        ↓
[你] 微信/钉钉收到推送
        ↓
[MaxClaw] 告诉你"✅ 已推"
```

## 用户自己申请 PAT 步骤

1. 打开 https://github.com/settings/tokens
2. **Generate new token** → **Generate new token (classic)**
3. Note: 写"Mavis Investment Assistant"
4. Expiration: 90 days(到期重新生成)
5. Scopes 勾选:
   - ✅ `repo`(Full control of private repositories)
   - ✅ `workflow`(Update GitHub Action workflows)
6. **Generate token**
7. 复制 `ghp_xxxxxxxxxxxx`(只显示一次!)
8. 存到 MaxClaw 环境变量 `GITHUB_PAT`
